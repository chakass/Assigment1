from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory data store
accounts = {
    '123456': {'account_number': '123456', 'balance': 5000},
    '789012': {'account_number': '789012', 'balance': 3000}
}


# Helper functions
def get_account(account_number):
    return accounts.get(account_number)


def update_account(account_number, amount):
    if accounts.get(account_number):
        accounts[account_number]['balance'] += amount
        return True
    return False


# TransferService API
@app.route('/transfer', methods=['POST'])
def transfer():
    data = request.get_json()
    source = data['source']
    destination = data['destination']
    amount = data['amount']

    # Basic validation
    if not (source and destination and amount and amount > 0):
        return jsonify({'error': 'Invalid data'}), 400

    # Check accounts exist
    if not get_account(source) or not get_account(destination):
        return jsonify({'error': 'Account not found'}), 404

    # Check sufficient funds
    if accounts[source]['balance'] < amount:
        return jsonify({'error': 'Insufficient funds'}), 403

    # Process the transfer
    update_account(source, -amount)
    update_account(destination, amount)

    return jsonify({'message': 'Transfer successful'}), 200


if __name__ == '__main__':
    app.run(debug=True)
