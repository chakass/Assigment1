import requests

# Base URL of the Flask server
BASE_URL = 'http://127.0.0.1:5000'


def make_transfer(source, destination, amount):
    # Construct the URL for the transfer endpoint
    url = f"{BASE_URL}/transfer"

    # Prepare the data payload as JSON
    payload = {
        'source': source,
        'destination': destination,
        'amount': amount
    }

    # Send the POST request
    response = requests.post(url, json=payload)

    # Print the status code and response data
    print("Status Code:", response.status_code)
    print("Response:", response.json())


# Test cases
def main():
    # Test transfer with valid data
    print("Test 1: Valid transfer")
    make_transfer('123456', '789012', 1000)

    # Test transfer with insufficient funds
    print("\nTest 2: Transfer with insufficient funds")
    make_transfer('123456', '789012', 10000)

    # Test transfer to non-existent account
    print("\nTest 3: Transfer to non-existent account")
    make_transfer('123456', '000000', 500)


if __name__ == '__main__':
    main()
