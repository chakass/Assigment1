import unittest
import app


class TestTransferService(unittest.TestCase):

    def setUp(self):
        app.app.testing = True
        self.app = app.app.test_client()

    def test_transfer_success(self):
        response = self.app.post('/transfer', json={
            'source': '123456',
            'destination': '789012',
            'amount': 1000
        })
        self.assertEqual(response.status_code, 200)

    def test_transfer_insufficient_funds(self):
        response = self.app.post('/transfer', json={
            'source': '123456',
            'destination': '789012',
            'amount': 10000
        })
        self.assertEqual(response.status_code, 403)

    def test_transfer_invalid_account(self):
        response = self.app.post('/transfer', json={
            'source': '111111',
            'destination': '789012',
            'amount': 500
        })
        self.assertEqual(response.status_code, 404)


if __name__ == '__main__':
    unittest.main()
